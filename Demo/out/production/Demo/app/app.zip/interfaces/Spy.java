package app.interfaces;

public interface Spy {

    String getCodeNumber();
}

package app.interfaces;

import app.Corp;

public interface SpecialisedSoldier {

    Corp getCorp();
}

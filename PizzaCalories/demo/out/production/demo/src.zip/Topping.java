public class Topping {
    private ToppingType toppingType;
    private double weight;

    public Topping(String toppingType, double weight) {
        this.setToppingType(toppingType);
        this.setWeight(weight);
    }

    public ToppingType getToppingType() {
        return toppingType;
    }

    private void setToppingType(String toppingType) {
        switch (toppingType) {
            case "Cheese":
            case "Meat":
            case "Veggies":
            case "Sauce":
                this.toppingType = ToppingType.valueOf(toppingType.toUpperCase());
                break;
            default:
                throw new IllegalArgumentException(String.
                        format("Cannot place %s on top of your pizza.", toppingType));
        }


    }

    public double getWeight() {
        return weight;
    }

    private void setWeight(double weight) {
        if (weight < 1 || weight > 50) {
            throw new IllegalArgumentException(String.
                    format("%s weight should be in the range [1..50].", this.getToppingType().name()));
        }
        this.weight = weight;
    }

    public double calculateCalories() {
        return 2 * this.getWeight() * toppingType.getModifier();
    }
}

public class Dough {
    private FlourType flourType;
    private BakingTechnique bakingTechnique;
    private double weight;

    public Dough(String flourType, String bakingTechnique, double weight) {
        this.setFlourType(flourType);
        this.setBakingTechnique(bakingTechnique);
        this.setWeight(weight);
    }

    public FlourType getFlourType() {
        return flourType;
    }

    private void setFlourType(String flourType) {
        switch (flourType) {
            case "White":
            case "Wholegrain":
                this.flourType = FlourType.valueOf(flourType.toUpperCase());
                break;
            default:
                throw new IllegalArgumentException("Invalid type of dough.");
        }

    }

    public BakingTechnique getBakingTechnique() {
        return bakingTechnique;
    }

    private void setBakingTechnique(String bakingTechnique) {
        switch (bakingTechnique) {
            case "Crispy":
            case "Chewy":
            case "Homemade":
                this.bakingTechnique = BakingTechnique.valueOf(bakingTechnique.toUpperCase());
                break;
            default:
                throw new IllegalArgumentException("Invalid type of dough.");
        }
    }

    public double getWeight() {
        return weight;
    }

    private void setWeight(double weight) {
        if (weight < 1 || weight > 200) {
            throw new IllegalArgumentException("Dough weight should be in the range [1..200].");
        }

        this.weight = weight;
    }

    public double calculateCalories() {
        return 2 * this.getWeight() * this.getBakingTechnique().getModifier()
                * this.getFlourType().getModifier();
    }
}
